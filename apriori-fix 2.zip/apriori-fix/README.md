1. Buka terminal baru di vscode
2. Jln in "git pull origin main
2. Jln in "php artisan serve"
3. Jln in "npm run dev"
4. Open http://127.0.0.1:8000 di browser
