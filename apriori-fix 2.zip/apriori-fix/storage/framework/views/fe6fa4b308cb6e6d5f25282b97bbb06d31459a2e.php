<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <h4 class="header-title">Detail Penjualan</h4>
            <p class="card-title-desc">
                No Faktur : <strong><?php echo e($kdFaktur); ?></strong>
            </p>

            <div class="table-responsive">
                <table class="table mb-0 table-hover" id="tblDetailPenjualan">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Kd Produk</th>
                            <th>Nama Produk</th>
                            <th>Qt</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dataPenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penjualan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop -> iteration); ?></td>
                            <td><?php echo e(substr($penjualan -> kd_barang, 0, 5)); ?></td>
                            <td><?php echo e($penjualan -> dataProduk($penjualan -> kd_barang) -> nama_produk); ?></td>
                            <td><?php echo e($penjualan -> qt); ?></td>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Sites/localhost/apriori-fix/resources/views/transaksi/detailPenjualan.blade.php ENDPATH**/ ?>