

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <a href="<?php echo e(route('produk.index')); ?>"><span class="float-end btn btn-primary fs-22 text-white">Kembali</span></a>
        </div>
        <div class="card-body">
            <img src="<?php echo e(Storage::url($produk->gambar)); ?>" alt="" height="100">
            <p class="fs-1"><?php echo e($produk->nama_produk); ?></p>
            <p>Rp. <?php echo e(number_format($produk->harga, 0, ',', '.')); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Sites/localhost/apriori-implement/resources/views/produk/show.blade.php ENDPATH**/ ?>