

<?php $__env->startSection('before-content'); ?>
    <form action="<?php echo e(route('produk.search')); ?>" method="GET">
        <div class="container-xxl container-p-y">
            <div class="row">
                <div class="col-4">
                    <input type="text" name="nama_produk" class="form-control mb-2 border-2"
                        placeholder="Cari Nama Produk..." value="<?php echo e(request('nama_produk')); ?>" />
                </div>
                <div class="col-6">
                    <button type="submit" class="btn btn-primary" name="search">Cari</button>
                </div>
                <?php if(auth()->user()->role === 'admin'): ?>
                    <div class="col">
                        <a href="<?php echo e(route('produk.create')); ?>" class="btn btn-warning">Tambah</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Basic Bootstrap Table -->
    <?php if(Auth::user()->role == 'admin'): ?>

    <div class="card">
        <h5 class="card-header bg-primary text-white">Data Produk</h5>
        <div class="table-responsive" style="box-shadow: 0 0 4px  gray;">
            <table class="table-hover table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Foto</th>
                        <th>Nama Produk</th>
                        <th class="text-end">Harga</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <img src="<?php echo e(Str::contains($produk->gambar, 'pixabay') ? $produk->gambar : Storage::url($produk->gambar)); ?>"
                                    style="width: 100px; height : 100px">
                            </td>
                            <td>
                                <i class="fab fa-angular fa-lg text-danger me-3"></i>
                                <?php echo e($produk->nama_produk); ?>

                            </td>
                            <td class="text-end">
                                <span>Rp. <?php echo e(number_format($produk['harga'], 0, ',', '.')); ?></span>
                               
                                
                                <a class="btn btn-primary m-2" href="<?php echo e(route('produk.edit', $produk->id)); ?>">
                                    <i class="bx bx-edit-alt me-1 text-white"></i>
                                </a>
                                    <form method="POST" action="<?php echo e(route('produk.destroy', $produk->id)); ?>"
                                        onsubmit="return confirm('Yakin ingin menghapus' . $produk['nama_produk'] . '?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger" type="submit">
                                            <i class="bx bx-trash me-1 text-white"></i>
                                        </button>
                                    </form>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <!--/ Basic Bootstrap Table -->
    <hr class="m-5" />
    <div class="row">

    <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-4 col-md-4 col-sm-6 p-2">
        <div class="card " style="width: 18rem;">
            <img src="<?php echo e(Str::contains($produk->gambar, 'pixabay') ? $produk->gambar : asset($produk->gambar)); ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($produk->nama_produk); ?></h5>
              
              <p   class="btn btn-primary">Rp. <?php echo e(number_format($produk['harga'], 0, ',', '.')); ?></p>
            </div>
          </div>
    </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Sites/localhost/apriori-implement/resources/views/produk/index.blade.php ENDPATH**/ ?>