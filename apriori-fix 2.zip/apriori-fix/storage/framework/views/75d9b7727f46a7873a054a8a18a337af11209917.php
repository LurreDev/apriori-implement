

<?php $__env->startSection('content'); ?>
    <!-- Basic Bootstrap Table -->
    <div class="card">
        <h5 class="card-header bg-primary text-white">Data Admin</h5>
        <div class="table-responsive" style="box-shadow: 0 0 4px  gray;">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Nama</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>

                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($user->username); ?></td>
                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($user->nama); ?></td>
                            <td style="display: block;">
                                <a class="btn btn-primary m-2" href="<?php echo e(route('akun.edit', $user->id)); ?>">
                                    <i class="bx bx-edit-alt me-1 text-white"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!--/ Basic Bootstrap Table -->
    <hr class="m-5" />

    <!-- Basic Bootstrap Table -->
    <div class="card">
        <h5 class="card-header bg-primary text-white">Data User</h5>
        <div class="table-responsive" style="box-shadow: 0 0 4px  gray;">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Nama</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>

                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($td->username); ?></td>
                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($td->nama); ?></td>
                            <td style="display: block;">
                                <a class="btn btn-primary m-2" href="<?php echo e(route('akun.edit', $td->id)); ?>">
                                    <i class="bx bx-edit-alt me-1 text-white"></i>
                                </a>
                                <form action="<?php echo e(route('akun.destroy', $td->id)); ?>" method="POST"
                                    onsubmit="return confirm('Yakin ingin menghapus <?php echo e($td->nama); ?> ?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">
                                        <i class="bx bx-trash me-1 text-white"></i>
                                    </button>

                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!--/ Basic Bootstrap Table -->
    <hr class="m-5" />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Sites/localhost/apriori-implement/resources/views/user/index.blade.php ENDPATH**/ ?>