

<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role === 'admin'): ?>
        <div class="row gx-0">
            <div class="col-md-6 mb-4">
                <a href="<?php echo e(route('transaksi.create')); ?>" class="btn btn-warning">Tambah</a>
            </div>
            <div class="col-md-6">
                <form action="<?php echo e(route('transaksi.index')); ?>" method="GET" class="row justify-content-end align-items-end">
                    <div class="col-md-4">
                        <label for="startDate" class="form-label">Start Date</label>
                        <input type="date" class="form-control" id="startDate" name="start_date">
                    </div>
                    <div class="col-md-4">
                        <label for="endDate" class="form-label">End Date</label>
                        <input type="date" class="form-control" id="endDate" name="end_date">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary btn-block">
                            Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <a href="<?php echo e(route('algoritma.apriori')); ?>" class="btn btn-info">Lihat Apriori</a>
        <a href="<?php echo e(route('transaksi.import.index')); ?>" class="btn btn-info">Import Transaksi</a>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Basic Bootstrap Table -->
    <div class="card">
        <h5 class="card-header bg-primary text-white">Data Transaksi</h5>
        <div class="table-responsive" style="box-shadow: 0 0 4px  gray;">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ID Transaksi</th>
                        <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th>Produk <?php echo e($loop->iteration); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-warning">
                            <td colspan="<?php echo e(count($produks)+3); ?>"><i class="fab fa-angular fa-lg text-danger me-3"></i>
                                <?php echo e(date('d M Y', strtotime($key))); ?>

                            </td>
                        </tr>
                        
                        <?php $__currentLoopData = $td; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><i class="fab fa-angular fa-lg text-danger me-3"></i>
                                    traksaksi #<?php echo e($trx->id); ?>

                                </td>
    
                                <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($trx->transaksiItems->where('produks_id', $produk->id)->count() > 0 ? 'Yes' : 'No'); ?>

                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="display: block;">
                                    <form action="<?php echo e(route('transaksi.destroy', $trx->id)); ?>" method="POST"
                                        onsubmit="return confirm('Yakin ingin menghapus transaksi ini ?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">
                                            <i class="bx bx-trash me-1 text-white"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!--/ Basic Bootstrap Table -->
    <hr class="m-5" />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Sites/localhost/apriori-fix/resources/views/transaksi/index.blade.php ENDPATH**/ ?>