<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->role === 'admin'): ?>
<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <h4 class="header-title">Hasil Analisa Apriori</h4>

            <p class="card-title-desc">
            <h5>Data Support Produk</h5>
            </p>

            <div class="table-responsive">
                <table class="table mb-0 table-hover" id="tblDataSupport">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Kd Produk</th>
                            <th>Nama Produk</th>
                            <th>Total Transaksi</th>
                            <th>Perhitungan Support</th>
                            <th>Support</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dataSupport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop -> iteration); ?></td>
                            <td><?php echo e(substr($supp -> kd_produk, 0, 5)); ?></td>
                            <td><?php echo e($supp -> dataProduk($supp -> kd_produk) -> nama_produk); ?></td>
                            <td><?php echo e($supp -> totalTransaksi($supp -> kd_produk)); ?></td>
                            <td>
                                (<?php echo e($supp -> totalTransaksi($supp -> kd_produk)); ?> / <?php echo e($totalProduk); ?> ) * 100
                            </td>
                            <td><?php echo e($supp -> support); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <hr />
            <p class="card-title-desc">
            <h5>Item yang memenuhi syarat minimun support <?php echo e($dataPengujian -> min_supp); ?> %</h5>
            </p>
            <div class="table-responsive">
                <table class="table mb-0 table-hover" id="tblDataSupportMin">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Kd Produk</th>
                            <th>Nama Produk</th>
                            <th>Support</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $dataMinSupport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minSupp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop -> iteration); ?></td>
                        <td><?php echo e(substr($minSupp -> kd_produk, 0, 5)); ?></td>
                        <td><?php echo e($minSupp -> dataProduk($minSupp -> kd_produk) -> nama_produk); ?></td>
                        <td><?php echo e($minSupp -> support); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <hr />
            <p class="card-title-desc">
            <h5>Kombinasi 2 itemset</h5>
            </p>
            <div class="table-responsive">
                <table class="table mb-0 table-hover" id="tblKombinasiItemset">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Kd Kombinasi</th>
                            <th>Produk A</th>
                            <th>Produk B</th>
                            <th>Jumlah Transaksi</th>
                            <th>Perhitungan Support</th>
                            <th>Support</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $dataKombinasiItemset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop -> iteration); ?></td>
                        <td><?php echo e(substr($is -> kd_kombinasi, 0, 5)); ?></td>
                        <td><?php echo e($is -> dataProduk($is -> kd_barang_a) -> nama_produk); ?></td>
                        <td><?php echo e($is -> dataProduk($is -> kd_barang_b) -> nama_produk); ?></td>
                        <td><?php echo e($is -> jumlah_transaksi); ?></td>
                        <td>( <?php echo e($is -> jumlah_transaksi); ?> / <?php echo e($totalProduk); ?> ) * 100</td>
                        <td><?php echo e($is -> support); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <hr />
            <p class="card-title-desc">
            <h5>Kombinasi yang memenuhi minimum confidence > <?php echo e($dataPengujian -> min_confidence); ?>%</h5>
            </p>
            <div class="table-responsive">
                <table class="table mb-0 table-hover" id="tblMinConfidence">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Kd Kombinasi</th>
                            <th>Produk A</th>
                            <th>Produk B</th>
                            <th>Jumlah Transaksi</th>
                            <th>Perhitungan Support</th>
                            <th>Support</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $dataMinConfidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop -> iteration); ?></td>
                        <td><?php echo e(substr($is -> kd_kombinasi, 0, 5)); ?></td>
                        <td><?php echo e($is -> dataProduk($is -> kd_barang_a) -> nama_produk); ?></td>
                        <td><?php echo e($is -> dataProduk($is -> kd_barang_b) -> nama_produk); ?></td>
                        <td><?php echo e($is -> jumlah_transaksi); ?></td>
                        <td>( <?php echo e($is -> jumlah_transaksi); ?> / <?php echo e($totalProduk); ?> ) * 100</td>
                        <td><?php echo e($is -> support); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <hr />
            <p class="card-title-desc">
            <h5>Pola hasil analisa</h5>
            </p>
            <div class="table-responsive">
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Pola</th>
                            <th>Confidence</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $dataMinConfidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop -> iteration); ?></td>
                        <td>
                            Apabila pelanggan membeli <b><?php echo e($is -> dataProduk($is -> kd_barang_a) -> nama_produk); ?></b>, 
                            maka pelanggan juga akan membeli <b><?php echo e($is -> dataProduk($is -> kd_barang_b) -> nama_produk); ?></b>
                        </td>
                        <td><?php echo e(floor($is -> support)); ?> %</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div>
                <a href="<?php echo e(url('/apriori/analisa/cetak/')); ?>/<?php echo e($kdPengujian); ?>" target="new" class="btn btn-primary btn-lg">Cetak Laporan Analisa</a>
            </div>


        </div>
    </div>
</div>
<?php endif; ?>

<?php if(auth()->user()->role === 'user'): ?>
<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
<hr />
<p class="card-title-desc">
<h5>Pola hasil analisa</h5>
</p>
<div class="table-responsive">
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>#</th>
                <th>Pola</th>
                <th>Confidence</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $dataMinConfidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop -> iteration); ?></td>
            <td>
                Apabila pelanggan membeli <b><?php echo e($is -> dataProduk($is -> kd_barang_a) -> nama_produk); ?></b>, 
                maka pelanggan juga akan membeli <b><?php echo e($is -> dataProduk($is -> kd_barang_b) -> nama_produk); ?></b>
            </td>
            <td><?php echo e($is -> support); ?> %</td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
        </div></div>

<?php endif; ?>


<script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>

<script >
$(document).ready(function(){
    $('#tblDataSupport').DataTable();
    $('#tblDataSupportMin').DataTable();
    $('#tblKombinasiItemset').DataTable();
    $('#tblMinConfidence').DataTable();
    $('#tblPolaHasil').DataTable();
});
    // $("#").dataTable();
    // $("#").dataTable();
    // $("#").dataTable();
    // $("#").dataTable();
    // $("#").dataTable();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Sites/localhost/apriori-fix/resources/views/apriori/hasilAnalisa.blade.php ENDPATH**/ ?>