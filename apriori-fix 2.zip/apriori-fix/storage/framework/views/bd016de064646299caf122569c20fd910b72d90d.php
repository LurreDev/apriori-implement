

<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <h4 class="header-title">Data Penjualan</h4>
            <p class="card-title-desc">
                
                <form action="<?php echo e(url('/app/penjualan/import')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="formFileTransaksi" class="form-label">Import excel</label>
                    <input class="form-control" type="file" name="file_excel" id="formFileTransaksi" required>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                
            </p>

            <div class="table-responsive">
                <table class="table mb-0 table-hover" id="tblDataPenjualan">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>No Faktur</th>
                            <th>Total Produk</th>
                            <th>Total Qt</th>
                            <th>Total Harga</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dataPenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penjualan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop -> iteration); ?></td>
                            <td>F-<?php echo e($penjualan -> no_faktur); ?></td>
                            <td><?php echo e($penjualan -> hitungTransaksi($penjualan -> no_faktur)); ?></td>
                            <td><?php echo e($penjualan -> hitungTotalQt($penjualan -> no_faktur)); ?></td>
                            <td>Rp. <?php echo e(number_format($penjualan -> getTotalHarga($penjualan -> no_faktur))); ?></td>
                            <td>
                                <a class="btn btn-primary btn-sm waves-effect waves-light" href="<?php echo e(url('/app/penjualan/detail',$penjualan ->no_faktur)); ?>">
                                    <i class="mdi mdi-folder-edit-outline"></i>
                                    Detail
                                </a>&nbsp;
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>
    <hr class="m-5" />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Sites/localhost/apriori-fix/resources/views/transaksi/index2.blade.php ENDPATH**/ ?>