

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body d-flex gap-3">
            <div class="alert alert-primary flex-grow-1 text-center" role="alert">
                <p class="fw-bold fs-4">minSupportCount</p>
                <p class="fw-bold fs-5"><?php echo e($stepByStep['minSupportCount']); ?></p>
            </div>
            <div class="alert alert-primary flex-grow-1 text-center" role="alert">
                <p class="fw-bold fs-4">minConfidence</p>
                <p class="fw-bold fs-5"><?php echo e($stepByStep['minConfidence'] * 100 . '%'); ?></p>
            </div>
            <div class="alert alert-primary flex-grow-1 text-center" role="alert">
                <p class="fw-bold fs-4">transactionCount</p>
                <p class="fw-bold fs-5"><?php echo e($stepByStep['transactionCount']); ?></p>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <h5 class="card-header bg-primary text-white">Transaction</h5>

        <div class="table-responsive" style="box-shadow: 0 0 4px  gray;">
            <table class="table-hover table">
                <thead>
                    <tr>
                        <th>Nomor</th>
                        <th>Produk ID</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $stepByStep['transactions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <?php
                                $getProduks = \App\Models\Produk::whereIn('id', $transaction)
                                    ->get()
                                    ->toArray();
                            ?>
                            <?php $__currentLoopData = $getProduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($item['nama_produk'] . (!$loop->last ? ',' : '')); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <h5 class="card-header bg-primary text-white">Produk</h5>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table-hover table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Harga</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($prod->id); ?></td>
                                <td><?php echo e($prod->nama_produk); ?></td>
                                <td><?php echo e($prod->harga); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <h5 class="card-header bg-primary text-white">Iteration</h5>

        <div class="card-body">
            <?php $__currentLoopData = $stepByStep['iteration']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iterate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col border-end border-primary">
                        <h5>Iteration <?php echo e($loop->iteration); ?>: Frequent Items</h5>
                        <div class="table-responsive">
                            <table class="table-hover table">
                                <thead>
                                    <tr>
                                        <th>Produk ID</th>
                                        <th>Support Count</th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                    <?php $__currentLoopData = $iterate['frequentItems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $frequentItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php
                                                    $arrProd = explode('-', $key);
                                                ?>
                                                <?php $__currentLoopData = $arrProd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(route('produk.show', $prod)); ?>"><?php echo e($prod); ?></a>
                                                    <?php echo e(!$loop->last ? ', ' : ''); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <?php echo e(number_format((float) (($frequentItems / count($stepByStep['transactions'])) * 100), 2, '.', '')); ?>%
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col">
                        <h5>Iteration <?php echo e($loop->iteration); ?>: filtered FrequentItems</h5>
                        <div class="table-responsive">
                            <table class="table-hover table">
                                <thead>
                                    <tr>
                                        <th>Produk ID</th>
                                        <th>Support Count</th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                    <?php $__currentLoopData = $iterate['filteredFrequentItems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $filteredFrequentItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(str_replace('-', ',', (string) $key)); ?></td>
                                            <td>
                                                <?php echo e(number_format((float) (($filteredFrequentItems / count($stepByStep['transactions'])) * 100), 2, '.', '')); ?>%
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="card mb-4">
        <h5 class="card-header bg-primary text-white">Rules</h5>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table-hover table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>if</th>
                            <th>then</th>
                            <th>confidence</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $stepByStep['rules']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rules): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(implode(',', $rules['if'])); ?></td>
                                <td><?php echo e(implode(',', $rules['then'])); ?></td>
                                <td><?php echo e($rules['confidence'] * 100 . '%'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <h5 class="card-header bg-primary text-white">Filtered Rules</h5>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table-hover table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>if</th>
                            <th>then</th>
                            <th>confidence</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $stepByStep['filteredRules']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filteredRules): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(implode(',', $filteredRules['if'])); ?></td>
                                <td><?php echo e(implode(',', $filteredRules['then'])); ?></td>
                                <td><?php echo e($filteredRules['confidence'] * 100 . '%'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Sites/localhost/apriori-implement/resources/views/algoritma/apriori.blade.php ENDPATH**/ ?>