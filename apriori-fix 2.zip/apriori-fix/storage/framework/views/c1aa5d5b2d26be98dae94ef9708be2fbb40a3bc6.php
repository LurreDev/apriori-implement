

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('akun.index')); ?>" class="mb-3">
        <span class="btn btn-outline-primary fs-22 mb-3">
            Kembali </span>
    </a>

    <form action="<?php echo e(route('edit-var.update')); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="min_confidence">Min Confidence</label>
            <input type="number" id="min_confidence" class="form-control" name="min_confidence"
                value="<?php echo e($staticVar->min_confidence); ?>" placeholder="min confidence" max="1" min="0.0"
                step="0.01" required>
        </div>

        <div>
            <label for="min_support">Min Support</label>
            <input type="number" class="form-control" id="min_support" name="min_support"
                value="<?php echo e($staticVar->min_support); ?>" placeholder="min confidence" step="0.01" required>
            <button type="submit" class="btn btn-primary mt-3">Change</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Sites/localhost/apriori-fix/resources/views/edit-confidence.blade.php ENDPATH**/ ?>